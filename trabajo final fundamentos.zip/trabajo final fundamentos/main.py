import json
import os
import sys
import random
from module.player import Player
from module.dungeon import Dungeon
from module.events import handle_event, loot_event, pedir_decision

# -----------------------------
# Guardado y carga
# -----------------------------
def guardar_partida(player, dungeon):
    data = {
        "player": player.to_dict(),
        "dungeon": dungeon.to_dict()
    }
    with open("save.json", "w") as f:
        json.dump(data, f, indent=4)
    print("\n💾 Partida guardada.\n")

def cargar_partida():
    if not os.path.exists("save.json"):
        print("\n❌ No hay partida guardada.\n")
        return None, None
    with open("save.json", "r") as f:
        data = json.load(f)
    player = Player(data["player"])
    dungeon = Dungeon(size=data["dungeon"]["size"], data=data["dungeon"])
    print("\n📂 Partida cargada.\n")
    return player, dungeon

# -----------------------------
# Mostrar estadísticas
# -----------------------------
def show_stats(p):
    print(f"\nHP: {p.hp} | ATK: {p.atk} | DEF: {p.defense} | Oro: {p.gold} | Nivel: {p.level}\n")

# -----------------------------
# Bucle principal del juego
# -----------------------------
def game_loop(player, dungeon):
    print("\n=== ESCAPE DE LA MAZMORRA ===")
    print("Controles: W A S D")
    print("Comandos: save / load / inv / usar / exit\n")

    while True:
        show_stats(player)
        move = input("> ").lower()

        # Salir al menú
        if move == "exit":
            print("\nSaliendo al menú principal...\n")
            break

        # Guardado / carga
        if move == "save":
            guardar_partida(player, dungeon)
            continue
        if move == "load":
            player, dungeon = cargar_partida()
            continue

        # Inventario
        if move == "inv":
            if player.inventory:
                print("\n📦 Inventario:")
                for i, item in enumerate(player.inventory, 1):
                    print(f"{i}. {item}")
            else:
                print("\n📦 Inventario vacío.")
            continue

        # Usar objetos
        if move.startswith("usar"):
            try:
                _, num = move.split()
                idx = int(num) - 1
                if 0 <= idx < len(player.inventory):
                    item = player.inventory.pop(idx)
                    if item == "poción":
                        player.hp += 20
                        print("✔ Usaste una poción. +20 HP")
                    elif item == "arma":
                        player.atk += 3
                        print("✔ Usaste un arma. +3 ATK")
                    elif item == "oro":
                        player.gold += 30
                        print("✔ Usaste oro. +30")
                else:
                    print("❌ Índice inválido")
            except:
                print("❌ Uso correcto: usar <número>")
            continue

        # Movimiento
        if move == "w": player.move(0, -1)
        elif move == "s": player.move(0, 1)
        elif move == "a": player.move(-1, 0)
        elif move == "d": player.move(1, 0)
        else:
            print("Movimiento inválido.")
            continue

        tile = dungeon.get_tile(player.x, player.y)
        if tile is None:
            print("Te golpeas contra una pared. Retrocedes.")
            continue

        handle_event(player, tile)

# -----------------------------
# Menú principal
# -----------------------------
def menu_principal():
    while True:
        print("=================================")
        print("     🏰 ESCAPE DE LA MAZMORRA     ")
        print("=================================")
        print("1. Nueva partida")
        print("2. Cargar partida")
        print("3. Salir")
        print("=================================")

        opcion = input("Selecciona una opción: ")

        if opcion == "1":
            print("\n🔥 Nueva partida iniciada.\n")
            player = Player()
            dungeon = Dungeon(size=5)
            game_loop(player, dungeon)

        elif opcion == "2":
            player, dungeon = cargar_partida()
            if player is not None:
                game_loop(player, dungeon)

        elif opcion == "3":
            print("\n👋 ¡Gracias por jugar!\n")
            sys.exit()

        else:
            print("\n❌ Opción no válida.\n")

if __name__ == "__main__":
    menu_principal()
