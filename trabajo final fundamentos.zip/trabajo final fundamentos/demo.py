import random

# ----------------------------
# Clases mínimas de prueba
# ----------------------------
class Player:
    def __init__(self):
        self.hp = 50
        self.atk = 10
        self.defense = 3
        self.gold = 0
        self.x = 0
        self.y = 0

    def move(self, dx, dy):
        self.x += dx
        self.y += dy


class Enemy:
    def __init__(self):
        self.hp = 20
        self.atk = 5
        self.defense = 1

# ----------------------------
# Manejo de eventos simples
# ----------------------------
def handle_event(player):
    event = random.choice(["nada", "enemigo", "cofre", "trampa"])

    if event == "nada":
        print("No pasa nada...")
    
    elif event == "enemigo":
        print("⚔️ ¡Un enemigo aparece!")
        enemy = Enemy()
        while player.hp > 0 and enemy.hp > 0:
            dmg = max(1, player.atk - enemy.defense)
            enemy.hp -= dmg
            print(f"Atacas al enemigo por {dmg}. HP enemigo: {enemy.hp}")

            if enemy.hp <= 0:
                print("✔️ Enemigo derrotado.")
                player.gold += 10
                break

            # Enemigo golpea
            dmg = max(1, enemy.atk - player.defense)
            player.hp -= dmg
            print(f"El enemigo te golpea por {dmg}. Tus HP: {player.hp}")

        if player.hp <= 0:
            print("💀 Moriste. Fin de la demo.")
            exit()

    elif event == "cofre":
        print("🎁 ¡Encontraste un cofre!")
        reward = random.choice(["poción", "oro", "nada"])
        if reward == "poción":
            print("Ganas +10 HP.")
            player.hp += 10
        elif reward == "oro":
            print("Ganas 20 de oro.")
            player.gold += 20
        else:
            print("El cofre estaba vacío.")

    elif event == "trampa":
        dmg = random.randint(3, 12)
        print(f"💥 ¡Pisaste una trampa! Pierdes {dmg} HP.")
        player.hp -= dmg

# ----------------------------
# Demo principal
# ----------------------------
def main():
    print("=== DEMO SIMPLE DE MAZMORRA ===")
    print("Controles: W A S D\n")

    player = Player()

    while True:
        print(f"\nPosición: ({player.x}, {player.y}) | HP: {player.hp} | Oro: {player.gold}")
        move = input("> ").lower()

        if move == "w": player.move(0, -1)
        elif move == "s": player.move(0, 1)
        elif move == "a": player.move(-1, 0)
        elif move == "d": player.move(1, 0)
        else:
            print("Movimiento no válido.")
            continue

        handle_event(player)


if __name__ == "__main__":
    main()
