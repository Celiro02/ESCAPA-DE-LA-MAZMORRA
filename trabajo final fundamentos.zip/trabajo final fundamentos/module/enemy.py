import random

class Enemy:
    def __init__(self, level=1, data=None):
        if data is None:
            self.level = level
            self.hp = 20 + (level * 5)
            self.atk = 5 + level
            self.defense = 2 + level
        else:
            self.level = data["level"]
            self.hp = data["hp"]
            self.atk = data["atk"]
            self.defense = data["defense"]

    def take_damage(self, dmg):
        real = max(1, dmg - self.defense)
        self.hp -= real
        return real

    def attack_player(self, player):
        return player.take_damage(self.atk)

    def to_dict(self):
        return {
            "level": self.level,
            "hp": self.hp,
            "atk": self.atk,
            "defense": self.defense
        }
    