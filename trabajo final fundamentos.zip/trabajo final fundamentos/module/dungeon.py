import random

class Dungeon:
    def __init__(self, size=5, data=None):
        self.size = size
        if data is None:
            self.grid = self.generate_map()
        else:
            self.grid = data["grid"]

    def generate_map(self):
        grid = []
        for _ in range(self.size):
            row = []
            for _ in range(self.size):
                tile = random.choice([0,0,0,1,2,3])
                row.append(tile)
            grid.append(row)
        grid[self.size - 1][self.size - 1] = 4  # jefe final
        return grid

    def get_tile(self, x, y):
        if 0 <= x < self.size and 0 <= y < self.size:
            return self.grid[y][x]
        return None

    def to_dict(self):
        return {
            "size": self.size,
            "grid": self.grid
        }
