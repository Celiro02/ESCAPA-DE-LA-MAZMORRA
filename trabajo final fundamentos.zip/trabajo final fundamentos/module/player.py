class Player:
    def __init__(self, data=None):
        if data is None:
            self.hp = 100
            self.atk = 10
            self.defense = 5
            self.gold = 0
            self.level = 1
            self.exp = 0
            self.x = 0
            self.y = 0
            self.inventory = []
        else:
            self.hp = data["hp"]
            self.atk = data["atk"]
            self.defense = data["defense"]
            self.gold = data["gold"]
            self.level = data["level"]
            self.exp = data["exp"]
            self.x = data["x"]
            self.y = data["y"]
            self.inventory = data["inventory"]

    def take_damage(self, dmg):
        real = max(1, dmg - self.defense)
        self.hp -= real
        return real

    def attack_enemy(self, enemy):
        return enemy.take_damage(self.atk)

    def gain_exp(self, amount):
        self.exp += amount
        if self.exp >= 100:
            self.level += 1
            self.exp = 0
            self.atk += 2
            self.hp += 10
            print(f"\n📈 ¡Subiste al nivel {self.level}!\n")

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def to_dict(self):
        return {
            "hp": self.hp,
            "atk": self.atk,
            "defense": self.defense,
            "gold": self.gold,
            "level": self.level,
            "exp": self.exp,
            "x": self.x,
            "y": self.y,
            "inventory": self.inventory
        }
