import random
from module.enemy import Enemy

# -----------------------------
# Función para pedir decisión
# -----------------------------
def pedir_decision(mensaje):
    while True:
        eleccion = input(f"{mensaje} (agarrar / dejar): ").lower()
        if eleccion in ["agarrar", "a"]:
            return True
        if eleccion in ["dejar", "d"]:
            return False
        print("❌ Opción inválida. Escribe 'agarrar' o 'dejar'.")

# -----------------------------
# Manejo de eventos
# -----------------------------
def handle_event(player, tile):
    if tile == 0:
        print("Nada aquí, solo polvo.")
    elif tile == 1:
        enemy = Enemy(player.level)
        combat(player, enemy)
    elif tile == 2:
        loot_event(player)
    elif tile == 3:
        trap_event(player)
    elif tile == 4:
        boss_fight(player)

# -----------------------------
# Cofres / loot con inventario
# -----------------------------
def loot_event(player):
    reward = random.choice(["poción", "oro", "arma", "nada"])
    print("\n🎁 ¡Cofre encontrado!")

    if reward == "nada":
        print("El cofre está vacío.\n")
        return

    # Preguntar si quiere agarrar el objeto
    if not pedir_decision(f"Encontraste {reward}. ¿Quieres agarrarlo?"):
        print("✖ Dejaste el objeto.\n")
        return

    # Guardar el objeto en inventario
    player.inventory.append(reward)
    print(f"✔ Has guardado {reward} en tu inventario.\n")

# -----------------------------
# Combate
# -----------------------------
def combat(player, enemy):
    print("\n⚔️ ¡Un enemigo aparece!\n")
    while player.hp > 0 and enemy.hp > 0:
        dmg = player.attack_enemy(enemy)
        print(f"Atacaste e hiciste {dmg} de daño. (Enemigo HP: {enemy.hp})")

        if enemy.hp <= 0:
            print("✔️ Enemigo derrotado.\n")
            player.gain_exp(30)
            player.gold += 10
            break

        dmg = enemy.attack_player(player)
        print(f"El enemigo te golpea por {dmg}. (Tu HP: {player.hp})")

    if player.hp <= 0:
        print("\n💀 Moriste. Fin del juego.")
        exit()

# -----------------------------
# Trampas
# -----------------------------
def trap_event(player):
    dmg = random.randint(5, 20)
    print(f"\n💥 Pisa una trampa! Pierdes {dmg} HP.\n")
    player.hp -= dmg

# -----------------------------
# Jefe final
# -----------------------------
def boss_fight(player):
    print("\n🔥 ¡Entras en la sala del jefe final!\n")
    boss = Enemy(level=player.level + 3)
    boss.hp += 50
    boss.atk += 5
    combat(player, boss)
    print("🏆 ¡Venciste al jefe final! ¡Ganaste el dungeon!\n")
    exit()
